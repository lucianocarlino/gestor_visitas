from app.schemas.api_contracts import ConsumibleCreateRequest, ConsumibleUpdateRequest, LowStockAlert
from app.schemas.domain import Consumible
from app.services.base import DatabaseBackedService


class ConsumableService(DatabaseBackedService):
    async def list_all(self) -> list[Consumible]:
        self._database_operation("list consumables")

    async def list_low_stock_alerts(self) -> list[LowStockAlert]:
        self._database_operation("find critical consumables at or below minimum stock")

    async def create(self, data: ConsumibleCreateRequest) -> Consumible:
        self._database_operation("create consumable")

    async def update(self, consumable_id: str, data: ConsumibleUpdateRequest) -> Consumible:
        self._database_operation(f"update consumable {consumable_id}")

    async def delete(self, consumable_id: str) -> bool:
        self._database_operation(f"delete consumable {consumable_id}")

    async def toggle_critical(self, consumable_id: str) -> Consumible:
        self._database_operation(f"toggle critical flag for consumable {consumable_id}")

    async def restock(self, consumable_id: str, amount: float) -> Consumible:
        self._database_operation(f"restock consumable {consumable_id} by {amount}")
