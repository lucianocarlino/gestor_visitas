from collections.abc import Awaitable
from typing import TypeVar

from fastapi import HTTPException

from app.services.exceptions import PersistenceNotImplementedError, ServiceError

ResultT = TypeVar("ResultT")


async def execute(operation: Awaitable[ResultT]) -> ResultT:
    """Translate typed service errors into stable HTTP responses."""
    try:
        return await operation
    except PersistenceNotImplementedError as error:
        raise HTTPException(status_code=501, detail=str(error)) from error
    except ServiceError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
