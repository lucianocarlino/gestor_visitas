import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True, slots=True)
class DatabaseSettings:
    url: str
    echo: bool


@lru_cache(maxsize=1)
def get_database_settings() -> DatabaseSettings:
    return DatabaseSettings(
        url=os.getenv("DATABASE_URL", "sqlite:///./visit_manager.db"),
        echo=os.getenv("DATABASE_ECHO", "false").lower() == "true",
    )
