from fastapi import APIRouter, Query, Response

from app.api.common import execute
from app.schemas.api_contracts import (
    CreateVisitResponse, EnumsResponse, ExportZipRequest, SyncBatchRequest,
    SyncBatchResponse,
)
from app.schemas.domain import (
    CodigoMotivo, CodigoOrden, CodigoTipoServicio, CreateVisitDTO, Status,
    StatusTecnico, Vehiculo, Visita,
)
from app.services.visit_service import VisitService

visits_router = APIRouter(prefix="/api/visits", tags=["visits"])
visits = VisitService()


def _enum_values(enum_type: type[Status] | type[StatusTecnico] | type[Vehiculo]
                 | type[CodigoMotivo] | type[CodigoOrden]
                 | type[CodigoTipoServicio]) -> dict[str, str]:
    return {member.name: member.value for member in enum_type}


@visits_router.get("/enums", response_model=EnumsResponse)
async def get_enums() -> EnumsResponse:
    return EnumsResponse(payload={
        "status": _enum_values(Status),
        "statusTecnico": _enum_values(StatusTecnico),
        "vehiculo": _enum_values(Vehiculo),
        "codigoMotivo": _enum_values(CodigoMotivo),
        "codigoOrden": _enum_values(CodigoOrden),
        "codigoTipoServicio": _enum_values(CodigoTipoServicio),
    })


@visits_router.post("", response_model=CreateVisitResponse)
async def create_visit(dto: CreateVisitDTO) -> CreateVisitResponse:
    return await execute(visits.create(dto))


@visits_router.post("/sync-batch", response_model=SyncBatchResponse)
async def sync_batch(payload: SyncBatchRequest) -> SyncBatchResponse:
    return await execute(visits.sync_batch(payload.visits))


@visits_router.get("", response_model=list[Visita])
async def get_all_visits() -> list[Visita]:
    return await execute(visits.list_all())


@visits_router.get("/filter/date-range", response_model=list[Visita])
async def filter_by_date_range(
    start: str = Query(..., description="Fecha de inicio"),
    end: str = Query(..., description="Fecha de fin"),
) -> list[Visita]:
    return await execute(visits.filter_by_date_range(start, end))


@visits_router.post("/export-zip", response_class=Response)
async def export_zip(payload: ExportZipRequest) -> Response:
    archive = await execute(visits.export_zip(payload))
    headers = {"Content-Disposition": "attachment; filename=reports.zip"}
    return Response(content=archive, media_type="application/zip", headers=headers)


@visits_router.get("/{id}", response_model=Visita)
async def get_visit_by_id(id: str) -> Visita:
    return await execute(visits.get_by_id(id))
