from app.schemas.api_contracts import TecnicoCreateRequest, TecnicoStats, TecnicoUpdateRequest
from app.schemas.domain import Tecnico
from app.services.base import DatabaseBackedService


class TechnicianService(DatabaseBackedService):
    async def list_all(self) -> list[Tecnico]:
        self._database_operation("list technicians")

    async def activity_stats(self) -> list[TecnicoStats]:
        self._database_operation("aggregate technician activity")

    async def create(self, data: TecnicoCreateRequest) -> Tecnico:
        self._database_operation("create technician")

    async def update(self, technician_id: str, data: TecnicoUpdateRequest) -> Tecnico:
        self._database_operation(f"update technician {technician_id}")

    async def delete(self, technician_id: str) -> bool:
        self._database_operation(f"delete technician {technician_id}")
