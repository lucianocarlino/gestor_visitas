from app.schemas.api_contracts import ServiceCreateResponse
from app.schemas.domain import Cambio, CreateCambioDTO, CreateReeplaceDTO, CreateServiceDTO, Reemplazo, Servicio
from app.services.base import DatabaseBackedService


class OperationService(DatabaseBackedService):
    async def list_replacements(self) -> list[Reemplazo]:
        self._database_operation("list replacements")

    async def create_replacement(self, data: CreateReeplaceDTO) -> Reemplazo:
        self._database_operation("create replacement and update machine locations")

    async def list_brake_changes(self) -> list[Cambio]:
        self._database_operation("list brake changes")

    async def create_brake_change(self, data: CreateCambioDTO) -> Cambio:
        self._database_operation("create brake change and update associations")

    async def list_services(self) -> list[Servicio]:
        self._database_operation("list machine services")

    async def create_service(self, data: CreateServiceDTO) -> ServiceCreateResponse:
        self._database_operation("create service and decrement consumable stock")
