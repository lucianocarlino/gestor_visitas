from app.schemas.api_contracts import AuditEntryCreateRequest, AuditLogFilters
from app.schemas.domain import AuditEntry
from app.services.base import DatabaseBackedService


class AuditService(DatabaseBackedService):
    async def list_entries(self, filters: AuditLogFilters) -> list[AuditEntry]:
        self._database_operation("list filtered audit entries")

    async def create_entry(self, data: AuditEntryCreateRequest) -> AuditEntry:
        self._database_operation("create audit entry")
