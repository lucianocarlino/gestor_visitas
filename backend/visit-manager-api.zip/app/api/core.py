from fastapi import APIRouter, Query

from app.api.common import execute
from app.schemas.api_contracts import (
    AuditEntryCreateRequest, AuditLogFilters, AuthLoginRequest, AuthLoginResponse,
    CabezalCreateRequest, CabezalUpdateRequest, CaseteraCreateRequest,
    CaseteraUpdateRequest, ConsumibleCreateRequest, ConsumibleUpdateRequest,
    DashboardStats, DeleteResponse, EmpaqueCreateRequest, EmpaqueUpdateRequest,
    EquipmentByLocationResponse, FrenoCreateRequest, FrenoUpdateRequest,
    LowStockAlert, MovimientoCreateRequest, ProviderTelemetry,
    RestockConsumibleRequest, ServiceCreateResponse, TecnicoCreateRequest,
    TecnicoStats, TecnicoUpdateRequest, UnvisitedAlert,
)
from app.schemas.domain import (
    AuditEntry, Cabezal, Cambio, Casetera, Consumible, CreateCambioDTO,
    CreateReeplaceDTO, CreateServiceDTO, Empaque, Freno, Movimiento, Reemplazo,
    Servicio, Tecnico,
)
from app.services.audit_service import AuditService
from app.services.consumable_service import ConsumableService
from app.services.empaque_service import EmpaqueService
from app.services.machine_service import MachineService
from app.services.operation_service import OperationService
from app.services.system_service import SystemService
from app.services.technician_service import TechnicianService

core_router = APIRouter(prefix="/api/core", tags=["core"])
empaques = EmpaqueService()
machines = MachineService()
operations = OperationService()
consumables = ConsumableService()
technicians = TechnicianService()
system = SystemService()
audits = AuditService()


@core_router.get("/empaques", response_model=list[Empaque])
async def get_empaques() -> list[Empaque]:
    return await execute(empaques.list_all())


@core_router.get("/empaques/alerts/unvisited", response_model=list[UnvisitedAlert])
async def get_unvisited_alerts() -> list[UnvisitedAlert]:
    return await execute(empaques.list_unvisited_alerts())


@core_router.post("/empaques", response_model=Empaque)
async def create_empaque(data: EmpaqueCreateRequest) -> Empaque:
    return await execute(empaques.create(data))


@core_router.put("/empaques/{id}", response_model=Empaque)
async def update_empaque(id: str, data: EmpaqueUpdateRequest) -> Empaque:
    return await execute(empaques.update(id, data))


@core_router.delete("/empaques/{id}", response_model=DeleteResponse)
async def delete_empaque(id: str) -> DeleteResponse:
    return DeleteResponse(success=await execute(empaques.delete(id)))


@core_router.get("/machines/location/{empaque_id}", response_model=EquipmentByLocationResponse)
async def get_equipment_by_location(empaque_id: str) -> EquipmentByLocationResponse:
    return await execute(machines.equipment_by_location(empaque_id))


@core_router.get("/machines/movements", response_model=list[Movimiento])
async def get_all_movements() -> list[Movimiento]:
    return await execute(machines.list_movements())


@core_router.post("/machines/movements", response_model=Movimiento)
async def create_movimiento(data: MovimientoCreateRequest) -> Movimiento:
    return await execute(machines.create_movement(data))


@core_router.get("/machines/cabezales", response_model=list[Cabezal])
async def get_cabezales() -> list[Cabezal]:
    return await execute(machines.list_cabezales())


@core_router.post("/machines/cabezales", response_model=Cabezal)
async def create_cabezal(data: CabezalCreateRequest) -> Cabezal:
    return await execute(machines.create_cabezal(data))


@core_router.put("/machines/cabezales/{id}", response_model=Cabezal)
async def update_cabezal(id: str, data: CabezalUpdateRequest) -> Cabezal:
    return await execute(machines.update_cabezal(id, data))


@core_router.delete("/machines/cabezales/{id}", response_model=DeleteResponse)
async def delete_cabezal(id: str) -> DeleteResponse:
    return DeleteResponse(success=await execute(machines.delete_cabezal(id)))


@core_router.get("/machines/caseteras", response_model=list[Casetera])
async def get_caseteras() -> list[Casetera]:
    return await execute(machines.list_caseteras())


@core_router.post("/machines/caseteras", response_model=Casetera)
async def create_casetera(data: CaseteraCreateRequest) -> Casetera:
    return await execute(machines.create_casetera(data))


@core_router.put("/machines/caseteras/{numero}", response_model=Casetera)
async def update_casetera(numero: int, data: CaseteraUpdateRequest) -> Casetera:
    return await execute(machines.update_casetera(numero, data))


@core_router.delete("/machines/caseteras/{numero}", response_model=DeleteResponse)
async def delete_casetera(numero: int) -> DeleteResponse:
    return DeleteResponse(success=await execute(machines.delete_casetera(numero)))


@core_router.get("/machines/frenos", response_model=list[Freno])
async def get_frenos() -> list[Freno]:
    return await execute(machines.list_frenos())


@core_router.post("/machines/frenos", response_model=Freno)
async def create_freno(data: FrenoCreateRequest) -> Freno:
    return await execute(machines.create_freno(data))


@core_router.put("/machines/frenos/{id}", response_model=Freno)
async def update_freno(id: str, data: FrenoUpdateRequest) -> Freno:
    return await execute(machines.update_freno(id, data))


@core_router.delete("/machines/frenos/{id}", response_model=DeleteResponse)
async def delete_freno(id: str) -> DeleteResponse:
    return DeleteResponse(success=await execute(machines.delete_freno(id)))


@core_router.get("/operations/reemplazos", response_model=list[Reemplazo])
async def get_reemplazos() -> list[Reemplazo]:
    return await execute(operations.list_replacements())


@core_router.post("/operations/reemplazos", response_model=Reemplazo)
async def create_reemplazo(dto: CreateReeplaceDTO) -> Reemplazo:
    return await execute(operations.create_replacement(dto))


@core_router.get("/operations/cambios", response_model=list[Cambio])
async def get_cambios() -> list[Cambio]:
    return await execute(operations.list_brake_changes())


@core_router.post("/operations/cambios", response_model=Cambio)
async def create_cambio(dto: CreateCambioDTO) -> Cambio:
    return await execute(operations.create_brake_change(dto))


@core_router.get("/operations/servicios", response_model=list[Servicio])
async def get_servicios() -> list[Servicio]:
    return await execute(operations.list_services())


@core_router.post("/operations/servicios", response_model=ServiceCreateResponse)
async def create_servicio(dto: CreateServiceDTO) -> ServiceCreateResponse:
    return await execute(operations.create_service(dto))


@core_router.get("/consumibles", response_model=list[Consumible])
async def get_consumibles() -> list[Consumible]:
    return await execute(consumables.list_all())


@core_router.get("/consumibles/alerts/low-stock", response_model=list[LowStockAlert])
async def get_low_stock_alerts() -> list[LowStockAlert]:
    return await execute(consumables.list_low_stock_alerts())


@core_router.post("/consumibles", response_model=Consumible)
async def create_consumible(data: ConsumibleCreateRequest) -> Consumible:
    return await execute(consumables.create(data))


@core_router.put("/consumibles/{id}", response_model=Consumible)
async def update_consumible(id: str, data: ConsumibleUpdateRequest) -> Consumible:
    return await execute(consumables.update(id, data))


@core_router.delete("/consumibles/{id}", response_model=DeleteResponse)
async def delete_consumible(id: str) -> DeleteResponse:
    return DeleteResponse(success=await execute(consumables.delete(id)))


@core_router.patch("/consumibles/{id}/toggle-critical", response_model=Consumible)
async def toggle_critical_consumible(id: str) -> Consumible:
    return await execute(consumables.toggle_critical(id))


@core_router.post("/consumibles/{id}/restock", response_model=Consumible)
async def restock_consumible(id: str, payload: RestockConsumibleRequest) -> Consumible:
    return await execute(consumables.restock(id, payload.amount))


@core_router.get("/tecnicos", response_model=list[Tecnico])
async def get_tecnicos() -> list[Tecnico]:
    return await execute(technicians.list_all())


@core_router.get("/tecnicos/activity/stats", response_model=list[TecnicoStats])
async def get_tecnico_stats() -> list[TecnicoStats]:
    return await execute(technicians.activity_stats())


@core_router.post("/tecnicos", response_model=Tecnico)
async def create_tecnico(data: TecnicoCreateRequest) -> Tecnico:
    return await execute(technicians.create(data))


@core_router.put("/tecnicos/{id}", response_model=Tecnico)
async def update_tecnico(id: str, data: TecnicoUpdateRequest) -> Tecnico:
    return await execute(technicians.update(id, data))


@core_router.delete("/tecnicos/{id}", response_model=DeleteResponse)
async def delete_tecnico(id: str) -> DeleteResponse:
    return DeleteResponse(success=await execute(technicians.delete(id)))


@core_router.post("/auth/login", response_model=AuthLoginResponse)
async def auth_login(credentials: AuthLoginRequest) -> AuthLoginResponse:
    return await execute(system.login(credentials))


@core_router.get("/statistics/dashboard", response_model=DashboardStats)
async def get_dashboard_stats() -> DashboardStats:
    return await execute(system.dashboard_stats())


@core_router.get("/provider/telemetry", response_model=ProviderTelemetry)
async def get_provider_telemetry() -> ProviderTelemetry:
    return await execute(system.provider_telemetry())


@core_router.get("/audit-logs", response_model=list[AuditEntry])
async def get_audit_logs(
    category: str | None = Query(default=None), userId: str | None = Query(default=None),
    search: str | None = Query(default=None), startDate: str | None = Query(default=None),
    endDate: str | None = Query(default=None), limit: int | None = Query(default=None),
) -> list[AuditEntry]:
    filters = AuditLogFilters(category=category, userId=userId, search=search,
                              startDate=startDate, endDate=endDate, limit=limit)
    return await execute(audits.list_entries(filters))


@core_router.post("/audit-logs", response_model=AuditEntry)
async def create_audit_log(entry: AuditEntryCreateRequest) -> AuditEntry:
    return await execute(audits.create_entry(entry))
