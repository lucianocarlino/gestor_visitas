from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin
from app.models.common import generate_id


class ReemplazoModel(TimestampMixin, Base):
    __tablename__ = "reemplazos"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_id)
    fecha: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    motivo: Mapped[str] = mapped_column(String(500))
    retirado_id: Mapped[str] = mapped_column(String(80), index=True)
    retirado_tipo: Mapped[str] = mapped_column(String(20))
    instalado_id: Mapped[str] = mapped_column(String(80), index=True)
    instalado_tipo: Mapped[str] = mapped_column(String(20))
    empaque_id: Mapped[str] = mapped_column(ForeignKey("empaques.id"), index=True)
    empaque_nombre: Mapped[str] = mapped_column(String(150))
    tecnico_id: Mapped[str | None] = mapped_column(ForeignKey("tecnicos.id"), index=True)
    tecnico_nombre: Mapped[str | None] = mapped_column(String(150))


class CambioModel(TimestampMixin, Base):
    __tablename__ = "cambios"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_id)
    fecha: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    motivo: Mapped[str] = mapped_column(String(500))
    lugar: Mapped[str] = mapped_column(String(255))
    retirado_freno_id: Mapped[str] = mapped_column(ForeignKey("frenos.id"), index=True)
    instalado_freno_id: Mapped[str] = mapped_column(ForeignKey("frenos.id"), index=True)
    cabezal_id: Mapped[str] = mapped_column(ForeignKey("cabezales.id"), index=True)
    tecnico_id: Mapped[str | None] = mapped_column(ForeignKey("tecnicos.id"), index=True)
    tecnico_nombre: Mapped[str | None] = mapped_column(String(150))


class ServicioModel(TimestampMixin, Base):
    __tablename__ = "servicios"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=generate_id)
    machine_id: Mapped[str] = mapped_column(String(80), index=True)
    machine_type: Mapped[str] = mapped_column(String(20), index=True)
    fecha: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    resumen: Mapped[str] = mapped_column(String(500))
    trabajo_hecho: Mapped[str] = mapped_column(Text)
    tecnico_id: Mapped[str | None] = mapped_column(ForeignKey("tecnicos.id"), index=True)
    tecnico_nombre: Mapped[str | None] = mapped_column(String(150))

    consumibles: Mapped[list[ServicioConsumibleModel]] = relationship(
        back_populates="servicio", cascade="all, delete-orphan"
    )


class ServicioConsumibleModel(Base):
    __tablename__ = "servicio_consumibles"
    __table_args__ = (UniqueConstraint("servicio_id", "consumible_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    servicio_id: Mapped[str] = mapped_column(
        ForeignKey("servicios.id", ondelete="CASCADE"), index=True
    )
    consumible_id: Mapped[str] = mapped_column(ForeignKey("consumibles.id"), index=True)
    nombre: Mapped[str] = mapped_column(String(150))
    cantidad: Mapped[int] = mapped_column(Integer)

    servicio: Mapped[ServicioModel] = relationship(back_populates="consumibles")
