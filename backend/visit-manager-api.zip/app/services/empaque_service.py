from app.schemas.api_contracts import EmpaqueCreateRequest, EmpaqueUpdateRequest, UnvisitedAlert
from app.schemas.domain import Empaque
from app.services.base import DatabaseBackedService


class EmpaqueService(DatabaseBackedService):
    async def list_all(self) -> list[Empaque]:
        self._database_operation("list empaques")

    async def list_unvisited_alerts(self) -> list[UnvisitedAlert]:
        self._database_operation("find empaques not visited within the configured threshold")

    async def create(self, data: EmpaqueCreateRequest) -> Empaque:
        self._database_operation("create empaque")

    async def update(self, empaque_id: str, data: EmpaqueUpdateRequest) -> Empaque:
        self._database_operation(f"update empaque {empaque_id}")

    async def delete(self, empaque_id: str) -> bool:
        self._database_operation(f"delete empaque {empaque_id}")
