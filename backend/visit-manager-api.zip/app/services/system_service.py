from app.schemas.api_contracts import (
    AuthLoginRequest, AuthLoginResponse, DashboardStats, ProviderTelemetry,
)
from app.services.base import DatabaseBackedService


class SystemService(DatabaseBackedService):
    async def login(self, credentials: AuthLoginRequest) -> AuthLoginResponse:
        self._database_operation("find user, verify password hash, and create session")

    async def dashboard_stats(self) -> DashboardStats:
        self._database_operation("aggregate dashboard statistics")

    async def provider_telemetry(self) -> ProviderTelemetry:
        self._database_operation("collect provider telemetry")
