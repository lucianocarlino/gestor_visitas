from app.schemas.api_contracts import (
    CabezalCreateRequest, CabezalUpdateRequest, CaseteraCreateRequest,
    CaseteraUpdateRequest, EquipmentByLocationResponse, FrenoCreateRequest,
    FrenoUpdateRequest, MovimientoCreateRequest,
)
from app.schemas.domain import Cabezal, Casetera, Freno, Movimiento
from app.services.base import DatabaseBackedService


class MachineService(DatabaseBackedService):
    async def equipment_by_location(self, empaque_id: str) -> EquipmentByLocationResponse:
        self._database_operation(f"find equipment at empaque {empaque_id}")

    async def list_movements(self) -> list[Movimiento]:
        self._database_operation("list machine movements")

    async def create_movement(self, data: MovimientoCreateRequest) -> Movimiento:
        self._database_operation("create machine movement")

    async def list_cabezales(self) -> list[Cabezal]:
        self._database_operation("list cabezales")

    async def create_cabezal(self, data: CabezalCreateRequest) -> Cabezal:
        self._database_operation("create cabezal")

    async def update_cabezal(self, machine_id: str, data: CabezalUpdateRequest) -> Cabezal:
        self._database_operation(f"update cabezal {machine_id}")

    async def delete_cabezal(self, machine_id: str) -> bool:
        self._database_operation(f"delete cabezal {machine_id}")

    async def list_caseteras(self) -> list[Casetera]:
        self._database_operation("list caseteras")

    async def create_casetera(self, data: CaseteraCreateRequest) -> Casetera:
        self._database_operation("create casetera")

    async def update_casetera(self, number: int, data: CaseteraUpdateRequest) -> Casetera:
        self._database_operation(f"update casetera {number}")

    async def delete_casetera(self, number: int) -> bool:
        self._database_operation(f"delete casetera {number}")

    async def list_frenos(self) -> list[Freno]:
        self._database_operation("list frenos")

    async def create_freno(self, data: FrenoCreateRequest) -> Freno:
        self._database_operation("create freno")

    async def update_freno(self, machine_id: str, data: FrenoUpdateRequest) -> Freno:
        self._database_operation(f"update freno {machine_id}")

    async def delete_freno(self, machine_id: str) -> bool:
        self._database_operation(f"delete freno {machine_id}")
