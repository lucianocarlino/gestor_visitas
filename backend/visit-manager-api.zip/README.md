# Visit Manager API endpoint implementation

This package keeps the supplied `app.api` and `app.schemas` import layout and
adds domain-separated services under `app/services`.

SQLAlchemy 2.x persistence models are separated by domain under `app/models`.
Database configuration and session lifecycle live under `app/db`. Set
`DATABASE_URL` for the target database; local development defaults to SQLite.
The engine and session factory are created once, while `get_db_session` yields
a new session per request.

## Persistence boundary

Every operation that needs stored data stops at
`DatabaseBackedService._database_operation`. The comment there marks the exact
repository/database integration point. Until repositories are connected, those
operations return HTTP 501 with a descriptive operation name. This is
intentional: no fake persistence or silent empty result is used.

`GET /api/visits/enums` is database-independent and works immediately.

## Integration

Copy the `app` directory into the FastAPI project. Include `api_router` from
`app.api.router` in the main application. Implement or inject repository calls
inside each file in `app/services`.

Import `app.models` before creating tables or running initial metadata-based
migrations so every model is registered on `Base.metadata`. For production,
use Alembic migrations rather than `Base.metadata.create_all()`.

## Validation performed

- All 50 supplied route declarations import and register successfully.
- All Python files compile.
- No file exceeds 500 lines and no function exceeds 50 lines.
- Bare response dictionaries were replaced with named Pydantic contracts.
- Service exceptions are translated consistently at the API boundary.
